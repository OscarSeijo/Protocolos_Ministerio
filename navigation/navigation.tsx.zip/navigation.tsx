import React, {Component} from 'react';
import { StyleSheet, Text, View, Platform } from 'react-native';
import {createAppContainer, TabNavigator, TabBarBottom } from 'react-navigation';
import { createStackNavigator, createSwitchNavigator, Navigation } from 'react-navigation-stack';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import PropTypes from 'prop-types';

//import { Icon } from 'react-native-elements';
import Icon from 'react-native-vector-icons/FontAwesome';


 
// Importamos las vistas:
import HomeScreen from '../pages/HomeScreen';
//import ShowDataScreen from '../pages/ShowDataScreen';

import SearchScreen from '../pages/SearchScreen';
import CategoriaScreen from '../pages/CategoriasScreen';
import LibreriaScreen from '../pages/LibreriaScreen';
 

// //////////////////////////////////////////////////////////////////////////////////////////////////////
// //////////////////////////////////////////////////////////////////////////////////////////////////////




// Aquí trabajamos las variables de transición
const FadeTransition = (index, position) => {
 const sceneRange = [index - 1, index];
 const outputOpacity =  [0, 1];
 const transition = position.interpolate({
  inputRange: sceneRange,
  outputRange: outputOpacity,
 });

 return {
  opacity: transition
 }
}


// Aqui trabajamos las configuraciones de navegación:
const NavigationConfig = () => {
  return {
    screenInterpolator: (sceneProps) => {
      const position = sceneProps.position;
      const scene = sceneProps.scene;
      const index = scene.index;

      return FadeTransition(index, position);
    }
  }
}




// //////////////////////////////////////////////////////////////////////////////////////////////////////
// //////////////////////////////////////////////////////////////////////////////////////////////////////




// Aquí exportamos el navegador principal con sus vistas asignadas:


const MainNavigator = createStackNavigator({
  // Asignamos las vistas correspondientes:
  Home: HomeScreen,
  //data: ShowDataScreen,
}, {headerLayoutPreset: 'center'}, {transitionConfig: NavigationConfig});



const LibreriaNavigation = createStackNavigator({

  Libreria: LibreriaScreen,

}, {headerLayoutPreset: 'center'}, {transitionConfig: NavigationConfig});


const SearchNavigation =  createStackNavigator({

  Categoria: CategoriaScreen,
  Search: SearchScreen


}, {headerLayoutPreset: 'center'}, {transitionConfig: NavigationConfig});






// Creamos las opciones del menu bottom:
const AppBottomNavigator = createBottomTabNavigator(
  {
    // Entramos la route principal (MainNavigator)
    Home: MainNavigator,
    // Las otras vistas
   // Libreria: LibreriaNavigation,
    Search: SearchNavigation
 
  },
  {
    initialRouteName: 'Home',
    defaultNavigationOptions: ({ navigation }) => ({
      tabBarIcon: ({ tintColor }) => {
        const { routeName } = navigation.state;
        let iconName;


        if (routeName === 'Home'){
           iconName = 'home';
        } else if(routeName === 'Libreria'){
           iconName = 'book';
        } else if (routeName === 'Search'){
          iconName = 'search';
        }

        return <Icon color={tintColor} type="font-awesome" name={iconName} size={25}/>
      }
    }),

    // Controlamos el color de fondo cuando este activo e inactivo
    tabBarOptions: {
      activeBackgroundColor: 'white',
      inactiveBackgroundColor: 'white',
      activeTintColor: 'green',
      inactiveTintColor: 'grey',
      showLabel: false
    }

  }
);




// //////////////////////////////////////////////////////////////////////////////////////////////////////
// //////////////////////////////////////////////////////////////////////////////////////////////////////


// Exportamos el sistema de navegación:
//const AppStackNavigator = createAppContainer(MainNavigator);
const AppStackNavigator = createAppContainer(AppBottomNavigator);


export default AppStackNavigator;